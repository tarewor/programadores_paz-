const express = require('express'); /*Aquí se importa Express, que es una herramienta para crear servidores web de forma sencilla. */
const app = express();  /*Aquí se crea la aplicación del servidor. La variable app se usa para configurar las rutas y respuestas. */
  
/*El método get significa que el servidor va a responder cuando alguien entre desde el navegador.
El símbolo / representa la página principal. */
/* req : representa la solicitud del usuario. */
/*res : representa la respuesta que enviará el servidor. */
app.get('/', (req, res) => { 
  res.send('Servidor funcionando correctamente, mi pagina esta activa');  /*res.send(): sirve para enviar un mensaje al navegador. */
});

app.listen(3000, () => { /*Esta parte inicia el servidor en el puerto 3000. */
  console.log('Servidor ejecutándose en puerto 3000'); 
});